i3.compress("default:diamondblock", {
	replace = "diamond",
	by = {"bronze", "copper", "gold", "steel", "tin"}
})
