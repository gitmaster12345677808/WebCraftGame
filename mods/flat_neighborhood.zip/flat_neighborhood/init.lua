-- Flat Neighborhood Mod for Minetest
-- Forces flat terrain, generates stone/gravel roads, places houses in gridded plots with grass and trees, ensures backyards, and clears trees (including jungle trees) from roads

-- Helper function to check if a value is in a table
local function table_contains(table, element)
    for _, value in ipairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

-- Force flat mapgen
minetest.set_mapgen_setting("mg_name", "flat", true)
minetest.set_mapgen_setting("mgflat_ground_level", "4", true)
minetest.set_mapgen_setting("mgflat_spfactor", "0", true) -- No hills
minetest.set_mapgen_setting("mgflat_lakethreshold", "-1", true) -- No lakes
minetest.set_mapgen_setting("mg_flags", "nocaves,nodungeons", true) -- No caves or dungeons for clean flat world

-- Configuration table for houses
local houses = {
    {
        name = "house1",
        schematic = "house1.mts",
        size = {x = 9, y = 7, z = 9}
    },
    {
        name = "house2",
        schematic = "house2.mts",
        size = {x = 7, y = 6, z = 8}
    },
    -- Add more houses here, for example:
    -- {
    --     name = "house3",
    --     schematic = "house3.mts",
    --     size = {x = 9, y = 7, z = 9}
    -- },
    -- Add as many as you want!
}

-- Neighborhood generation on map chunk generation
minetest.register_on_generated(function(minp, maxp, seed)
    if #houses == 0 then
        minetest.log("error", "[flat_neighborhood] No houses defined in the houses table!")
        return
    end

    local modpath = minetest.get_modpath("flat_neighborhood")
    if not modpath then
        minetest.log("error", "[flat_neighborhood] Mod path not found. Please check mod installation.")
        return
    end

    local spacing = 24 -- Plot size (center-to-center, accommodates 9x9 houses, trees, and backyard)
    local road_width = 4 -- Width of roads (2 stone + 1 gravel each side)
    local surface_y = 4 -- Ground level for flat mapgen
    local road_node = "default:stone" -- Main road material
    local border_node = "default:gravel" -- Road border material
    local grass_node = "default:dirt_with_grass" -- Plot surface
    local tree_nodes = {"default:tree", "default:jungletree"} -- Tree trunks to clear and place
    local leaves_nodes = {"default:leaves", "default:jungleleaves"} -- Tree leaves to clear and place

    -- Verify nodes exist
    if not minetest.registered_nodes[road_node] then
        minetest.log("error", "[flat_neighborhood] Road node '" .. road_node .. "' not found. Replace with a valid node.")
        return
    end
    if not minetest.registered_nodes[border_node] then
        minetest.log("error", "[flat_neighborhood] Border node '" .. border_node .. "' not found. Replace with a valid node.")
        return
    end
    if not minetest.registered_nodes[grass_node] then
        minetest.log("error", "[flat_neighborhood] Grass node '" .. grass_node .. "' not found. Replace with a valid node.")
        return
    end
    local tree_available = true
    for _, node in ipairs(tree_nodes) do
        if not minetest.registered_nodes[node] then
            minetest.log("warning", "[flat_neighborhood] Tree node '" .. node .. "' not found. Trees will not be placed.")
            tree_available = false
            break
        end
    end
    for _, node in ipairs(leaves_nodes) do
        if not minetest.registered_nodes[node] then
            minetest.log("warning", "[flat_neighborhood] Leaves node '" .. node .. "' not found. Trees will not be placed.")
            tree_available = false
            break
        end
    end

    -- Generate roads and clear trees on roads
    for x = minp.x, maxp.x do
        for z = minp.z, maxp.z do
            if (x % spacing < road_width or x % spacing >= spacing - road_width) or
               (z % spacing < road_width or z % spacing >= spacing - road_width) then
                -- Place stone for road center (2 nodes) and gravel for borders (1 node each side)
                local node = (x % spacing == 0 or x % spacing == 3 or
                              z % spacing == 0 or z % spacing == 3) and border_node or road_node
                minetest.set_node({x = x, y = surface_y, z = z}, {name = node})
                -- Clear trees (including jungle trees) and leaves above roads
                for y = surface_y + 1, surface_y + 10 do
                    local pos = {x = x, y = y, z = z}
                    local node_name = minetest.get_node(pos).name
                    if node_name == "air" or table_contains(tree_nodes, node_name) or table_contains(leaves_nodes, node_name) then
                        minetest.set_node(pos, {name = "air"})
                    end
                end
            else
                -- Ensure plots have grass
                minetest.set_node({x = x, y = surface_y, z = z}, {name = grass_node})
            end
        end
    end

    -- Place houses and trees in the center of each plot
    for x = math.ceil(minp.x / spacing) * spacing + math.floor(spacing / 2), math.floor(maxp.x / spacing) * spacing + math.floor(spacing / 2), spacing do
        for z = math.ceil(minp.z / spacing) * spacing + math.floor(spacing / 2), math.floor(maxp.z / spacing) * spacing + math.floor(spacing / 2), spacing do
            -- Choose house type (cycle based on position)
            local house_index = ((math.floor((x - math.floor(spacing / 2)) / spacing) + math.floor((z - math.floor(spacing / 2)) / spacing)) % #houses) + 1
            local house = houses[house_index]
            local schematic_path = modpath .. "/schematics/" .. house.schematic

            -- Check if schematic file exists
            local file = io.open(schematic_path, "r")
            if not file then
                minetest.log("error", "[flat_neighborhood] Schematic file '" .. house.schematic .. "' not found in flat_neighborhood/schematics/")
                return
            end
            file:close()

            -- Ensure house fits within the plot
            local plot_size = spacing - road_width
            if house.size.x > plot_size or house.size.z > plot_size then
                minetest.log("warning", "[flat_neighborhood] House '" .. house.name .. "' (" .. house.size.x .. "x" .. house.size.z .. ") too large for plot size (" .. plot_size .. "x" .. plot_size .. "). Skipping.")
                return
            end

            -- Calculate house placement position (centered in plot)
            local offset_x = math.floor(house.size.x / 2)
            local offset_z = math.floor(house.size.z / 2)
            local pos1 = {x = x - offset_x, y = surface_y, z = z - offset_z}

            -- Place the house schematic
            minetest.place_schematic(pos1, schematic_path, "0", nil, true, {force_placement = true})

            -- Add a few trees in the plot (avoiding house and ensuring backyard space)
            if tree_available then
                local plot_min_x = x - math.floor(spacing / 2) + 2
                local plot_max_x = x + math.floor(spacing / 2) - 2
                local plot_min_z = z - math.floor(spacing / 2) + 2
                local plot_max_z = z + math.floor(spacing / 2) - 2
                -- Reserve backyard (upper half of plot in z-direction)
                local backyard_min_z = z + math.floor(house.size.z / 2) + 1
                local tree_count = math.random(2, 4) -- 2-4 trees per plot
                for i = 1, tree_count do
                    local tx = math.random(plot_min_x, plot_max_x)
                    local tz = math.random(plot_min_z, backyard_min_z - 2) -- Keep trees out of backyard
                    -- Avoid placing trees inside house area
                    if math.abs(tx - x) > math.ceil(house.size.x / 2) or math.abs(tz - z) > math.ceil(house.size.z / 2) then
                        -- Choose random tree type (regular or jungle)
                        local tree_index = math.random(1, #tree_nodes)
                        local tree = tree_nodes[tree_index]
                        local leaves = leaves_nodes[tree_index]
                        -- Simple tree: trunk with leaves
                        minetest.set_node({x = tx, y = surface_y + 1, z = tz}, {name = tree})
                        for ly = surface_y + 2, surface_y + 4 do
                            for lx = tx - 1, tx + 1 do
                                for lz = tz - 1, tz + 1 do
                                    if math.random() > 0.3 then -- Sparse leaves
                                        minetest.set_node({x = lx, y = ly, z = lz}, {name = leaves})
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)
