-- white_noise/init.lua
-- Constant white noise mod for Minetest

-- Store sound handles per-player so we can stop them if needed
local noise_handles = {}

-- Function to start noise for a player
local function start_noise(player)
    local name = player:get_player_name()
    if noise_handles[name] then
        return -- already playing
    end
    local handle = minetest.sound_play("white_noise", {
        to_player = name,
        gain = tonumber(minetest.settings:get("white_noise_gain") or 0.2),
        loop = true,
    })
    noise_handles[name] = handle
end

-- Function to stop noise for a player
local function stop_noise(player)
    local name = player:get_player_name()
    if noise_handles[name] then
        minetest.sound_stop(noise_handles[name])
        noise_handles[name] = nil
    end
end

-- Play noise when player joins
minetest.register_on_joinplayer(function(player)
    start_noise(player)
end)

-- Stop noise when player leaves
minetest.register_on_leaveplayer(function(player)
    stop_noise(player)
end)

-- Optional chat command to toggle noise per player
minetest.register_chatcommand("whitenoise", {
    params = "on|off",
    description = "Toggle constant white noise",
    func = function(name, param)
        local player = minetest.get_player_by_name(name)
        if not player then
            return false, "Player not found."
        end
        if param == "off" then
            stop_noise(player)
            return true, "White noise stopped."
        else
            start_noise(player)
            return true, "White noise started."
        end
    end,
})

